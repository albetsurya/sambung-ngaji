import { useState, type FormEvent } from "react";
import { useNavigate, useLocation, Navigate } from "react-router-dom";
import { Landmark, Sun, Moon, Eye, EyeOff } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useTheme } from "../contexts/ThemeContext";
import { Button, Input } from "../components/common";
import { ApiError } from "../services/api";

export default function LoginPage() {
  const { login, user, loading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!loading && user) {
    const from = (location.state as { from?: string })?.from || "/";
    return <Navigate to={from} replace />;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await login(username, password);
      navigate("/", { replace: true });
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.message
          : "Gagal masuk. Periksa koneksi Anda.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="app-shell min-h-screen flex flex-col bg-surface-bg relative overflow-hidden">
      {/* === Background dekorasi === */}
      <div
        aria-hidden
        className="pointer-events-none absolute -top-32 -right-24 w-72 h-72 rounded-full opacity-40 blur-3xl"
        style={{ background: "rgb(var(--c-accent) / 0.35)" }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-32 -left-24 w-80 h-80 rounded-full opacity-30 blur-3xl"
        style={{ background: "rgb(var(--c-accent) / 0.25)" }}
      />

      {/* === Theme toggle === */}
      <button
        onClick={toggleTheme}
        aria-label="Ganti mode tampilan"
        className="neu-press absolute top-6 right-6 z-50 w-10 h-10 flex items-center justify-center rounded-full bg-surface-card/80 backdrop-blur border border-surface-border shadow-card text-surface-text"
      >
        {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
      </button>

      {/* === Konten === */}
      <div className="flex-1 flex flex-col justify-center px-6 py-10 max-w-md w-full mx-auto relative z-10">
        {/* Logo & Judul */}
        <div className="mb-10 text-center animate-fade-up">
          <div className="relative w-20 h-20 mx-auto mb-5">
            <div
              className="absolute inset-0 rounded-[26px] blur-xl opacity-50"
              style={{ background: "rgb(var(--c-accent) / 0.5)" }}
            />
            <div className="relative w-20 h-20 rounded-[26px] bg-accent flex items-center justify-center shadow-neu-float">
              <Landmark size={32} className="text-white" strokeWidth={2.2} />
            </div>
          </div>

          <h1 className="text-[26px] font-semibold text-surface-text tracking-tight">
            Manajemen Pengajian
          </h1>
          <p className="text-ios-subhead text-surface-muted mt-2 leading-relaxed">
            Biodata jamaah, absensi, dan pembinaan
          </p>
        </div>

        {/* Form Card — rounded 24px */}
        <form
          onSubmit={handleSubmit}
          className="bg-surface-card/80 backdrop-blur-ios rounded-[24px] border border-surface-border shadow-card p-6 animate-fade-up"
          style={{ animationDelay: "80ms" }}
        >
          <div className="space-y-4">
            <Input
              label="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoComplete="username"
              placeholder="Masukkan username"
              required
            />

            <div className="relative">
              <Input
                label="Password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                placeholder="Masukkan password"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                aria-label={
                  showPassword ? "Sembunyikan password" : "Tampilkan password"
                }
                className="absolute right-3 top-[34px] p-1 text-surface-muted ios-active"
                tabIndex={-1}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <div className="mt-4 flex items-start gap-2 px-3 py-2.5 rounded-[16px] bg-danger/10 border border-danger/20 animate-fade-in">
              <span className="w-1.5 h-1.5 rounded-full bg-danger mt-1.5 flex-shrink-0" />
              <p className="text-ios-footnote text-danger leading-snug">
                {error}
              </p>
            </div>
          )}

          <div className="mt-6">
            <Button type="submit" fullWidth disabled={submitting}>
              {submitting ? (
                <span className="inline-flex items-center gap-2">
                  <span className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  Memproses...
                </span>
              ) : (
                "Masuk"
              )}
            </Button>
          </div>
        </form>

        {/* Footer */}
        <p
          className="text-center text-ios-caption text-surface-muted mt-8 animate-fade-up"
          style={{ animationDelay: "160ms" }}
        >
          © {new Date().getFullYear()} Manajemen Pengajian
        </p>
      </div>
    </div>
  );
}
