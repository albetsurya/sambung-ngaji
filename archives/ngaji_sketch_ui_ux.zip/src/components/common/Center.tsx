import type { ReactNode } from "react";

interface CenterProps {
  children: ReactNode;
  /** Isi seluruh tinggi layar (default: true) */
  fullscreen?: boolean;
  /** Class tambahan */
  className?: string;
}

export function Center({
  children,
  fullscreen = true,
  className = "",
}: CenterProps) {
  return (
    <div
      className={`flex items-center justify-center ${
        fullscreen ? "min-h-screen" : "h-full"
      } ${className}`}
    >
      {children}
    </div>
  );
}
