/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        surface: {
          bg: "rgb(var(--c-bg) / <alpha-value>)",
          card: "rgb(var(--c-card) / <alpha-value>)",
          card2: "rgb(var(--c-card2) / <alpha-value>)",
          border: "rgb(var(--c-border) / <alpha-value>)",
          muted: "rgb(var(--c-muted) / <alpha-value>)",
          text: "rgb(var(--c-text) / <alpha-value>)",
        },
        accent: {
          DEFAULT: "rgb(var(--c-accent) / <alpha-value>)",
          dark: "rgb(var(--c-accent-dark) / <alpha-value>)",
          soft: "rgb(var(--c-accent-light) / <alpha-value>)",
          softStrong: "rgb(var(--c-accent) / 0.16)",
        },
        success: {
          DEFAULT: "rgb(var(--c-success) / <alpha-value>)",
          soft: "rgb(var(--c-success) / 0.12)",
        },
        danger: {
          DEFAULT: "rgb(var(--c-danger) / <alpha-value>)",
          soft: "rgb(var(--c-danger) / 0.12)",
        },
        warning: {
          DEFAULT: "rgb(var(--c-warning) / <alpha-value>)",
          soft: "rgb(var(--c-warning) / 0.14)",
        },
        info: {
          DEFAULT: "rgb(var(--c-accent) / <alpha-value>)",
          soft: "rgb(var(--c-accent-light) / <alpha-value>)",
        },
      },

      fontFamily: {
        display: [
          "Inter",
          "Plus Jakarta Sans",
          "-apple-system",
          "BlinkMacSystemFont",
          "sans-serif",
        ],
        sans: [
          "Inter",
          "Plus Jakarta Sans",
          "-apple-system",
          "BlinkMacSystemFont",
          "sans-serif",
        ],
      },

      fontSize: {
        "ios-nav": ["17px", { lineHeight: "22px", fontWeight: "600" }],
        "ios-body": ["15px", { lineHeight: "22px" }],
        "ios-subhead": ["14px", { lineHeight: "20px" }],
        "ios-footnote": ["13px", { lineHeight: "18px" }],
        "ios-caption": ["11px", { lineHeight: "14px", fontWeight: "500" }],
        "ios-tab": ["10px", { lineHeight: "12px", fontWeight: "500" }],
      },

      boxShadow: {
        neu: "var(--shadow-card)",
        "neu-sm": "var(--shadow-card)",
        "neu-pressed":
          "0 0 0 1px rgb(var(--c-accent) / 0.16), 0 1px 2px rgb(0 0 0 / 0.03)",
        "neu-pressed-sm":
          "0 0 0 1px rgb(var(--c-accent) / 0.12), 0 1px 2px rgb(0 0 0 / 0.03)",
        "neu-float": "var(--shadow-float)",
        "neu-bar-top": "var(--shadow-bar)",
        "neu-bar-bottom": "0 1px 8px rgb(0 0 0 / 0.05)",
        card: "var(--shadow-card)",
        "ios-sheet": "0 -8px 30px rgb(0 0 0 / 0.12)",
        "ios-fab": "var(--shadow-float)",
      },

      borderRadius: {
        xl2: "1.25rem",
        ios: "0.875rem",
        neu: "1rem",
      },

      backdropBlur: {
        ios: "20px",
      },

      // ============================================================
      // TAMBAHAN: Animasi
      // ============================================================
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "fade-in": {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        "fade-down": {
          "0%": { opacity: "0", transform: "translateY(-8px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "scale-in": {
          "0%": { opacity: "0", transform: "scale(0.96)" },
          "100%": { opacity: "1", transform: "scale(1)" },
        },
        "slide-up": {
          "0%": { transform: "translateY(100%)" },
          "100%": { transform: "translateY(0)" },
        },
        "slide-down": {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(0)" },
        },
        shake: {
          "0%, 100%": { transform: "translateX(0)" },
          "20%, 60%": { transform: "translateX(-4px)" },
          "40%, 80%": { transform: "translateX(4px)" },
        },
        "pulse-soft": {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.6" },
        },
        "spin-slow": {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(360deg)" },
        },
      },

      animation: {
        "fade-up": "fade-up 500ms ease-out both",
        "fade-in": "fade-in 300ms ease-out both",
        "fade-down": "fade-down 300ms ease-out both",
        "scale-in": "scale-in 250ms ease-out both",
        "slide-up": "slide-up 350ms cubic-bezier(0.32, 0.72, 0, 1)",
        "slide-down": "slide-down 300ms cubic-bezier(0.32, 0.72, 0, 1)",
        shake: "shake 400ms ease-in-out",
        "pulse-soft": "pulse-soft 2s ease-in-out infinite",
        "spin-slow": "spin-slow 1.5s linear infinite",
      },

      // ============================================================
      // TAMBAHAN: Transition timing (opsional)
      // ============================================================
      transitionTimingFunction: {
        ios: "cubic-bezier(0.32, 0.72, 0, 1)",
        smooth: "cubic-bezier(0.4, 0, 0.2, 1)",
      },

      // ============================================================
      // TAMBAHAN: z-index scale (opsional, biar konsisten)
      // ============================================================
      zIndex: {
        header: "30",
        nav: "40",
        sheet: "50",
        modal: "60",
        toast: "70",
      },
    },
  },
  plugins: [],
};
