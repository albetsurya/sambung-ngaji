// api.ts
import type { ApiResponse } from "../types";
import { API_BASE_URL } from "../constants";

const TOKEN_KEY = "pengajian_token";

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

export async function call<T>(
  action: string,
  params: Record<string, any> = {},
): Promise<T> {
  const token = getToken();

  // Log environment
  console.log("🔍 Environment check:", {
    API_BASE_URL: API_BASE_URL,
    isProduction: import.meta.env.PROD,
    mode: import.meta.env.MODE,
    VITE_API_BASE_URL: import.meta.env.VITE_API_BASE_URL,
  });

  // Build form data
  const formData = new URLSearchParams();
  formData.append("action", action);
  if (token) formData.append("token", token);

  Object.keys(params).forEach((key) => {
    if (key !== "action" && key !== "token") {
      const value =
        typeof params[key] === "object"
          ? JSON.stringify(params[key])
          : String(params[key]);
      formData.append(key, value);
    }
  });

  // Log request
  console.log("📤 API Request:", {
    action,
    params,
    token: token ? "present" : "none",
    url: API_BASE_URL,
    formDataString: formData.toString(),
  });

  // Cek jika URL kosong
  if (!API_BASE_URL) {
    console.error("❌ API_BASE_URL is empty! Check your .env file");
    throw new ApiError("API_BASE_URL tidak ditemukan. Periksa file .env");
  }

  try {
    const response = await fetch(API_BASE_URL, {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
      },
      body: formData.toString(),
    });

    console.log("📥 Response status:", response.status);
    console.log("📥 Response ok:", response.ok);
    console.log(
      "📥 Response headers:",
      Object.fromEntries(response.headers.entries()),
    );

    // Ambil response text
    const text = await response.text();
    console.log("📝 Raw response (first 500 chars):", text.substring(0, 500));

    // Cek apakah response adalah HTML (error dari Google Apps Script)
    if (
      text.includes("<!DOCTYPE") ||
      text.includes("<html") ||
      text.includes("Google")
    ) {
      console.error(
        "❌ Response is HTML - likely error from Google Apps Script",
      );
      console.error("Full HTML:", text);
      throw new ApiError(
        "Server mengembalikan HTML error. Cek URL Web App dan deployment.",
      );
    }

    // Parse JSON
    let data: ApiResponse<T>;
    try {
      data = JSON.parse(text);
    } catch (e) {
      console.error("❌ Failed to parse JSON:", text);
      throw new ApiError(
        "Server mengembalikan response tidak valid (bukan JSON)",
      );
    }

    console.log("✅ Parsed response:", data);

    if (!data.success) {
      if (
        data.message?.toLowerCase().includes("unauthorized") ||
        data.message?.toLowerCase().includes("sesi tidak valid") ||
        data.message?.toLowerCase().includes("token")
      ) {
        clearToken();
        throw new ApiError("Sesi kadaluarsa, silakan login ulang", data);
      }
      throw new ApiError(data.message || "Terjadi kesalahan", data);
    }

    return data.data;
  } catch (error) {
    console.error("❌ API call error:", error);

    if (error instanceof ApiError) {
      throw error;
    }

    if (error instanceof Error) {
      if (
        error.message.includes("Failed to fetch") ||
        error.message.includes("NetworkError")
      ) {
        throw new ApiError(
          "Gagal terhubung ke server. Periksa koneksi internet dan URL Web App.",
        );
      }
      throw new ApiError(error.message);
    }

    throw new ApiError("Gagal terhubung ke server");
  }
}

export async function login(username: string, password: string) {
  console.log("🔐 login called with:", { username });
  try {
    const result = await call<{ token: string; user: any }>("login", {
      username,
      password,
    });
    if (result?.token) {
      console.log(
        "✅ Login success, token:",
        result.token.substring(0, 20) + "...",
      );
      setToken(result.token);
    }
    return result;
  } catch (error) {
    console.error("❌ Login failed:", error);
    throw error;
  }
}

export async function logout() {
  console.log("🔐 logout called");
  try {
    await call("logout", {});
  } catch (error) {
    console.error("Logout error:", error);
  } finally {
    clearToken();
  }
}

export class ApiError extends Error {
  response?: ApiResponse<unknown>;
  constructor(message: string, response?: ApiResponse<unknown>) {
    super(message);
    this.name = "ApiError";
    this.response = response;
  }
}

// Debug function - jalankan di browser console
export async function testApiConnection() {
  console.log("=== 🧪 TEST API CONNECTION ===");
  console.log("📋 Environment:", {
    API_BASE_URL: API_BASE_URL,
    mode: import.meta.env.MODE,
    VITE_API_BASE_URL: import.meta.env.VITE_API_BASE_URL,
  });

  if (!API_BASE_URL) {
    console.error("❌ API_BASE_URL is empty!");
    return { success: false, error: "API_BASE_URL empty" };
  }

  console.log("📤 Testing login with superadmin...");

  try {
    const formData = new URLSearchParams();
    formData.append("action", "login");
    formData.append("username", "superadmin");
    formData.append("password", "ganti123");

    console.log("📤 Request URL:", API_BASE_URL);
    console.log("📤 Request body:", formData.toString());

    const response = await fetch(API_BASE_URL, {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
      },
      body: formData.toString(),
    });

    console.log("📥 Status:", response.status);
    console.log("📥 Headers:", Object.fromEntries(response.headers.entries()));

    const text = await response.text();
    console.log("📝 Response (first 1000 chars):", text.substring(0, 1000));

    // Cek HTML
    if (text.includes("<!DOCTYPE") || text.includes("<html")) {
      console.error("❌ Response is HTML - Web App error");
      return {
        success: false,
        error: "HTML response",
        html: text.substring(0, 500),
      };
    }

    try {
      const json = JSON.parse(text);
      console.log("✅ JSON parsed:", json);
      return { success: true, data: json };
    } catch {
      console.error("❌ Not valid JSON");
      return { success: false, error: "Not JSON", raw: text.substring(0, 200) };
    }
  } catch (error) {
    console.error("❌ Connection error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// Test with different method (just in case)
export async function testApiConnectionJson() {
  console.log("=== 🧪 TEST API CONNECTION (JSON) ===");

  try {
    const payload = {
      action: "login",
      username: "superadmin",
      password: "ganti123",
    };

    const response = await fetch(API_BASE_URL, {
      method: "POST",
      mode: "cors",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(payload),
    });

    const text = await response.text();
    console.log("📝 Response:", text.substring(0, 500));

    try {
      const json = JSON.parse(text);
      console.log("✅ JSON parsed:", json);
      return { success: true, data: json };
    } catch {
      console.error("❌ Not valid JSON");
      return { success: false, error: "Not JSON", raw: text.substring(0, 200) };
    }
  } catch (error) {
    console.error("❌ Error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

export default {
  call,
  login,
  logout,
  getToken,
  setToken,
  clearToken,
  ApiError,
  testApiConnection,
  testApiConnectionJson,
};
