import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, SlidersHorizontal } from "lucide-react";
import {
  AppLayout,
  Header,
  FloatingActionButton,
} from "../components/layout/AppLayout";
import {
  Card,
  Avatar,
  Badge,
  LoadingState,
  ErrorState,
  EmptyState,
  BottomSheet,
  Button,
  Select,
} from "../components/common";
import { memberApi, type MemberFilters } from "../services/memberApi";
import type { Member, MemberCategory } from "../types";
import { CATEGORY_LABEL } from "../utils/format";
import { MEMBER_CATEGORIES } from "../constants";
import { usePermission } from "../hooks/usePermission";
import { ApiError } from "../services/api";

export default function MembersListPage() {
  const navigate = useNavigate();
  const { role } = usePermission();
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [kategori, setKategori] = useState<MemberCategory | "">("");
  const [filterOpen, setFilterOpen] = useState(false);
  const [jenisKelamin, setJenisKelamin] = useState("");

  async function load() {
    setLoading(true);
    setError("");
    try {
      const filters: MemberFilters = {};
      if (search) filters.search = search;
      if (kategori) filters.kategori = kategori;
      if (jenisKelamin) filters.jenis_kelamin = jenisKelamin;
      const fn = role === "TIM_PNKB" ? memberApi.listPNKB : memberApi.list;
      const res = await fn(filters);
      setMembers(res);
    } catch (err) {
      setError(
        err instanceof ApiError ? err.message : "Gagal memuat daftar jamaah",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, kategori, jenisKelamin]);

  const canCreate = role === "SUPER_ADMIN" || role === "ADMIN";

  return (
    <AppLayout>
      <Header title="Jamaah" subtitle={`${members.length} jamaah`} />
      <div
        className="px-4 pt-2 pb-2 flex gap-2 sticky z-20 backdrop-blur-ios bg-surface-bg/90"
        style={{ top: 'calc(44px + var(--safe-top))' }}
      >
        <div className="relative flex-1">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-muted"
          />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari nama jamaah"
            className="w-full min-h-[36px] rounded-xl border-none bg-surface-card2 shadow-neu-pressed-sm pl-9 pr-3.5 text-[16px] text-surface-text placeholder:text-surface-muted focus:outline-none"
          />
        </div>
        <button
          onClick={() => setFilterOpen(true)}
          className="neu-press min-h-[36px] px-3.5 rounded-xl bg-surface-card2 shadow-neu-sm text-ios-subhead font-medium text-surface-text flex items-center gap-1.5"
        >
          <SlidersHorizontal size={15} /> Filter
        </button>
      </div>

      <div className="px-4 pb-2 flex gap-2 overflow-x-auto no-scrollbar">
        <CategoryChip
          active={kategori === ""}
          label="Semua"
          onClick={() => setKategori("")}
        />
        {MEMBER_CATEGORIES.map((c) => (
          <CategoryChip
            key={c}
            active={kategori === c}
            label={CATEGORY_LABEL[c]}
            onClick={() => setKategori(c)}
          />
        ))}
      </div>

      <div className="px-4 py-2 space-y-2">
        {loading && <LoadingState />}
        {!loading && error && <ErrorState message={error} onRetry={load} />}
        {!loading && !error && members.length === 0 && (
          <EmptyState
            title="Belum ada jamaah"
            description="Coba ubah kata kunci pencarian atau filter kategori."
          />
        )}
        {!loading &&
          !error &&
          members.map((m) => (
            <Card
              key={m.member_id}
              onClick={() => navigate(`/jamaah/${m.member_id}`)}
              className="flex items-center gap-3"
            >
              <Avatar src={m.foto_url} name={m.nama_lengkap} />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-surface-text truncate">
                  {m.nama_lengkap}
                </p>
                <p className="text-xs text-surface-muted truncate">
                  {m.kelompok || "-"}
                </p>
              </div>
              {m.kategori && <Badge>{CATEGORY_LABEL[m.kategori]}</Badge>}
            </Card>
          ))}
      </div>

      {canCreate && (
        <FloatingActionButton onClick={() => navigate("/jamaah/baru")} />
      )}

      <BottomSheet
        open={filterOpen}
        onClose={() => setFilterOpen(false)}
        title="Filter Jamaah"
      >
        <Select
          label="Jenis Kelamin"
          value={jenisKelamin}
          onChange={(e) => setJenisKelamin(e.target.value)}
        >
          <option value="">Semua</option>
          <option value="L">Laki-laki</option>
          <option value="P">Perempuan</option>
        </Select>
        <Button fullWidth onClick={() => setFilterOpen(false)}>
          Terapkan
        </Button>
      </BottomSheet>
    </AppLayout>
  );
}

function CategoryChip({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`neu-press whitespace-nowrap px-3.5 py-1.5 rounded-full text-ios-footnote font-medium ${
        active
          ? "bg-accent text-white shadow-neu-sm"
          : "bg-surface-card2 text-surface-text/80 shadow-neu-pressed-sm"
      }`}
    >
      {label}
    </button>
  );
}
