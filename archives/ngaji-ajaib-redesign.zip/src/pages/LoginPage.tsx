import { useState, type FormEvent } from 'react';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import { Landmark, Sun, Moon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { Button, Input } from '../components/common';
import { ApiError } from '../services/api';

export default function LoginPage() {
  const { login, user, loading } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const location = useLocation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!loading && user) {
    const from = (location.state as { from?: string })?.from || '/';
    return <Navigate to={from} replace />;
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await login(username, password);
      navigate('/', { replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Gagal masuk. Periksa koneksi Anda.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="app-shell min-h-screen flex flex-col justify-center px-6 py-10 bg-surface-bg relative">
      <button
        onClick={toggleTheme}
        aria-label="Ganti mode tampilan"
        className="neu-press absolute top-6 right-6 w-9 h-9 flex items-center justify-center rounded-full bg-surface-card2 shadow-neu-sm text-surface-text"
      >
        {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
      </button>

      <div className="mb-10 text-center">
        <div className="w-16 h-16 mx-auto rounded-[22px] bg-accent flex items-center justify-center mb-4 shadow-neu-float">
          <Landmark size={28} className="text-white" />
        </div>
        <h1 className="text-[22px] font-semibold text-surface-text">Manajemen Pengajian</h1>
        <p className="text-ios-subhead text-surface-muted mt-1">Biodata jamaah, absensi, dan pembinaan</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-surface-card rounded-neu shadow-neu p-5">
        <Input
          label="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          autoComplete="username"
          required
        />
        <Input
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
          required
        />
        {error && <p className="text-ios-footnote text-danger mb-4">{error}</p>}
        <Button type="submit" fullWidth disabled={submitting}>
          {submitting ? 'Memproses...' : 'Masuk'}
        </Button>
      </form>
    </div>
  );
}
