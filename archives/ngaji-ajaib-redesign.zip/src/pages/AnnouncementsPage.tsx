import { useEffect, useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { AppLayout, Header, FloatingActionButton } from '../components/layout/AppLayout';
import { Badge, Button, Select, Input, Textarea, BottomSheet, Modal, LoadingState, EmptyState, GroupedList, ListRow } from '../components/common';
import { announcementApi, groupApi } from '../services/domainApi';
import type { Announcement, AnnouncementTemplate, Group } from '../types';
import { formatDateShort, getHariFromDate } from '../utils/format';
import { JADWAL_RUTIN } from '../constants';
import { useToast } from '../contexts/ToastContext';
import { usePermission } from '../hooks/usePermission';
import { ApiError } from '../services/api';

export default function AnnouncementsPage() {
  const { isAdminLike } = usePermission();
  const { showToast } = useToast();
  const [list, setList] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [preview, setPreview] = useState<Announcement | null>(null);

  async function load() {
    setLoading(true);
    try {
      const res = await announcementApi.list();
      setList(res);
    } catch (err) {
      showToast(err instanceof ApiError ? err.message : 'Gagal memuat pengumuman', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  return (
    <AppLayout>
      <Header title="Pengumuman" subtitle="Template WhatsApp pengajian" />

      <div className="py-3">
        {loading && <LoadingState />}
        {!loading && list.length === 0 && (
          <EmptyState title="Belum ada pengumuman" description="Buat pengumuman pertama untuk jadwal pengajian rutin." />
        )}
        {!loading && list.length > 0 && (
          <GroupedList>
            {list.map((a, i) => (
              <ListRow key={a.announcement_id} onClick={() => setPreview(a)} insetDivider={i !== list.length - 1}>
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-ios-body font-medium text-surface-text truncate">{a.acara || 'Pengumuman'}</p>
                    <p className="text-ios-footnote text-surface-muted truncate">{a.hari}, {formatDateShort(a.tanggal)}</p>
                  </div>
                  <Badge color={a.status === 'DRAFT' ? 'ink' : a.status === 'SHARED' ? 'emerald' : 'amber'}>{a.status}</Badge>
                </div>
              </ListRow>
            ))}
          </GroupedList>
        )}
      </div>

      {isAdminLike && <FloatingActionButton onClick={() => setCreateOpen(true)} />}

      <CreateAnnouncementSheet
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        onCreated={(a) => { setList((prev) => [a, ...prev]); setPreview(a); }}
      />

      <PreviewModal announcement={preview} onClose={() => setPreview(null)} />
    </AppLayout>
  );
}

function PreviewModal({ announcement, onClose }: { announcement: Announcement | null; onClose: () => void }) {
  const { showToast } = useToast();
  if (!announcement) return null;

  async function copyText() {
    try {
      await navigator.clipboard.writeText(announcement!.generated_text);
      showToast('Teks disalin');
    } catch {
      showToast('Gagal menyalin teks', 'error');
    }
  }

  async function shareWA() {
    if (navigator.share) {
      try {
        await navigator.share({ text: announcement!.generated_text });
      } catch {
        /* user membatalkan share, abaikan */
      }
    } else {
      const url = `https://wa.me/?text=${encodeURIComponent(announcement!.generated_text)}`;
      window.open(url, '_blank');
    }
  }

  return (
    <Modal open={!!announcement} onClose={onClose} title="Preview Pengumuman">
      <div
        className="rounded-2xl rounded-tl-sm shadow-neu-pressed-sm p-3.5 mb-4 max-h-[45vh] overflow-y-auto"
        style={{ background: 'rgb(var(--c-accent) / 0.12)' }}
      >
        <pre className="whitespace-pre-wrap text-[14.5px] leading-relaxed text-surface-text font-sans">{announcement.generated_text}</pre>
      </div>
      <div className="flex gap-3">
        <Button variant="ghost" fullWidth onClick={copyText}>Salin Teks</Button>
        <Button fullWidth onClick={shareWA}>Bagikan WhatsApp</Button>
      </div>
    </Modal>
  );
}

function CreateAnnouncementSheet({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (a: Announcement) => void }) {
  const { showToast } = useToast();
  const [templates, setTemplates] = useState<AnnouncementTemplate[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [templateId, setTemplateId] = useState('');
  const [groupId, setGroupId] = useState('');
  const [tanggal, setTanggal] = useState(new Date().toISOString().slice(0, 10));
  const [jam, setJam] = useState('Isya di tempat');
  const [acara, setAcara] = useState('Sambung Kelompok');
  const [materi, setMateri] = useState('');
  const [catatan, setCatatan] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    announcementApi.templates().then((t) => { setTemplates(t); if (t[0]) setTemplateId(t[0].template_id); });
    groupApi.list().then(setGroups);
  }, [open]);

  const hari = getHariFromDate(tanggal);
  const isRoutine = JADWAL_RUTIN.includes(hari);

  async function handleCreate() {
    setSaving(true);
    try {
      const created = await announcementApi.create({ template_id: templateId, group_id: groupId, tanggal, jam, acara, materi, catatan });
      showToast('Pengumuman dibuat');
      onCreated(created);
      onClose();
    } catch (err) {
      showToast(err instanceof ApiError ? err.message : 'Gagal membuat pengumuman', 'error');
    } finally {
      setSaving(false);
    }
  }

  return (
    <BottomSheet open={open} onClose={onClose} title="Buat Pengumuman">
      <Select label="Template" value={templateId} onChange={(e) => setTemplateId(e.target.value)}>
        {templates.map((t) => <option key={t.template_id} value={t.template_id}>{t.nama_template}</option>)}
      </Select>
      <Select label="Kelompok" value={groupId} onChange={(e) => setGroupId(e.target.value)}>
        <option value="">Pilih kelompok</option>
        {groups.map((g) => <option key={g.group_id} value={g.group_id}>{g.group_name}</option>)}
      </Select>
      <Input label="Tanggal" type="date" value={tanggal} onChange={(e) => setTanggal(e.target.value)} />
      {!isRoutine && (
        <p className="text-xs text-warning -mt-3 mb-4 flex items-center gap-1.5">
          <AlertTriangle size={13} /> Tanggal ini bukan jadwal rutin pengajian (Minggu/Selasa/Kamis).
        </p>
      )}
      <Input label="Jam" value={jam} onChange={(e) => setJam(e.target.value)} />
      <Input label="Acara" value={acara} onChange={(e) => setAcara(e.target.value)} />
      <Textarea label="Materi" value={materi} onChange={(e) => setMateri(e.target.value)} />
      <Textarea label="Catatan (NB)" value={catatan} onChange={(e) => setCatatan(e.target.value)} />
      <Button fullWidth onClick={handleCreate} disabled={saving || !groupId || !templateId}>
        {saving ? 'Membuat...' : 'Generate & Preview'}
      </Button>
    </BottomSheet>
  );
}
