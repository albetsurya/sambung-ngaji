import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Building2, KeyRound, Settings, ScrollText, LogOut, Sun, Moon } from 'lucide-react';
import { AppLayout, Header } from '../components/layout/AppLayout';
import { Avatar, ConfirmDialog, GroupedList, ListRow, ChevronRow } from '../components/common';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { usePermission } from '../hooks/usePermission';

export default function OthersPage() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { isAdminLike, isSuperAdmin } = usePermission();
  const navigate = useNavigate();
  const [confirmLogout, setConfirmLogout] = useState(false);

  const menu = [
    { key: 'kelompok', label: 'Kelompok', Icon: Building2, to: '/lainnya/kelompok', show: isAdminLike },
    { key: 'users', label: 'Manajemen User', Icon: KeyRound, to: '/lainnya/users', show: isSuperAdmin },
    { key: 'settings', label: 'Pengaturan', Icon: Settings, to: '/lainnya/pengaturan', show: isAdminLike },
    { key: 'audit', label: 'Audit Log', Icon: ScrollText, to: '/lainnya/audit-log', show: isSuperAdmin }
  ].filter((m) => m.show);

  return (
    <AppLayout>
      <Header title="Lainnya" />
      <div className="py-4">
        <GroupedList>
          <ListRow insetDivider={false} className="py-3">
            <div className="flex items-center gap-3">
              <Avatar name={user?.nama || '?'} size={48} />
              <div className="min-w-0">
                <p className="text-ios-body font-medium text-surface-text truncate">{user?.nama}</p>
                <p className="text-ios-footnote text-surface-muted truncate">{user?.username} · {roleLabel(user?.role)}</p>
              </div>
            </div>
          </ListRow>
        </GroupedList>

        <GroupedList>
          <ListRow onClick={toggleTheme} insetDivider={false}>
            <div className="flex items-center gap-3">
              <span className="w-7 h-7 rounded-lg bg-surface-card2 shadow-neu-pressed-sm flex items-center justify-center text-surface-text shrink-0">
                {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
              </span>
              <span className="flex-1 text-ios-body text-surface-text">Mode Tampilan</span>
              <span className="text-ios-footnote text-surface-muted">{theme === 'dark' ? 'Gelap' : 'Terang'}</span>
            </div>
          </ListRow>
        </GroupedList>

        {menu.length > 0 && (
          <GroupedList>
            {menu.map((m, i) => {
              const Icon = m.Icon;
              return (
                <ListRow
                  key={m.key}
                  onClick={() => navigate(m.to)}
                  insetDivider={i !== menu.length - 1}
                  leading={
                    <span className="w-7 h-7 rounded-lg bg-surface-card2 shadow-neu-pressed-sm flex items-center justify-center text-surface-text shrink-0">
                      <Icon size={15} />
                    </span>
                  }
                >
                  <ChevronRow>
                    <span className="text-ios-body text-surface-text">{m.label}</span>
                  </ChevronRow>
                </ListRow>
              );
            })}
          </GroupedList>
        )}

        <GroupedList>
          <ListRow onClick={() => setConfirmLogout(true)} insetDivider={false}>
            <div className="flex items-center justify-center gap-2 text-danger">
              <LogOut size={17} />
              <span className="text-ios-body font-medium">Keluar</span>
            </div>
          </ListRow>
        </GroupedList>
      </div>

      <ConfirmDialog
        open={confirmLogout}
        title="Keluar dari aplikasi?"
        description="Anda perlu login kembali untuk mengakses aplikasi."
        confirmLabel="Ya, Keluar"
        danger
        onCancel={() => setConfirmLogout(false)}
        onConfirm={() => { setConfirmLogout(false); logout(); }}
      />
    </AppLayout>
  );
}

function roleLabel(role?: string) {
  const map: Record<string, string> = {
    SUPER_ADMIN: 'Super Admin', ADMIN: 'Admin', TIM_PNKB: 'Tim PNKB', TIM_ABSENSI: 'Tim Absensi'
  };
  return role ? map[role] || role : '';
}
