import { useEffect, useMemo, useState } from 'react';
import { Search, Plus } from 'lucide-react';
import { AppLayout, Header } from '../components/layout/AppLayout';
import { Button, Card, LoadingState, EmptyState, BottomSheet, Select, Input } from '../components/common';
import { meetingApi, attendanceApi, groupApi } from '../services/domainApi';
import { memberApi } from '../services/memberApi';
import type { Meeting, Member, AttendanceRecord, AttendanceStatus, Group } from '../types';
import { ATTENDANCE_LABEL, formatDateLong, getHariFromDate } from '../utils/format';
import { ATTENDANCE_STATUSES, MEMBER_CATEGORIES } from '../constants';
import { CATEGORY_LABEL } from '../utils/format';
import { useToast } from '../contexts/ToastContext';
import { usePermission } from '../hooks/usePermission';
import { ApiError } from '../services/api';

const STATUS_STYLE: Record<AttendanceStatus, string> = {
  HADIR: 'bg-accent text-white',
  IJIN: 'bg-warning text-white',
  SAKIT: 'bg-info text-white',
  TANPA_KETERANGAN: 'bg-danger text-white'
};

export default function AttendancePage() {
  const { isAdminLike, role } = usePermission();
  const { showToast } = useToast();
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [selectedMeeting, setSelectedMeeting] = useState<Meeting | null>(null);
  const [members, setMembers] = useState<Member[]>([]);
  const [records, setRecords] = useState<Record<string, AttendanceStatus>>({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [createOpen, setCreateOpen] = useState(false);

  async function loadMeetings() {
    setLoading(true);
    try {
      const today = new Date().toISOString().slice(0, 10);
      const from = new Date(Date.now() - 14 * 86400000).toISOString().slice(0, 10);
      const list = await meetingApi.list({ from });
      setMeetings(list);
      const todays = list.find((m) => m.tanggal === today) || list[0] || null;
      setSelectedMeeting(todays);
    } catch (err) {
      showToast(err instanceof ApiError ? err.message : 'Gagal memuat jadwal pengajian', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadMeetings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedMeeting) return;
    (async () => {
      try {
        const [mList, att] = await Promise.all([
          memberApi.listForAttendance({}),
          attendanceApi.byMeeting(selectedMeeting.meeting_id)
        ]);
        setMembers(mList);
        const map: Record<string, AttendanceStatus> = {};
        att.forEach((a) => { map[a.member_id] = a.status; });
        setRecords(map);
      } catch (err) {
        showToast(err instanceof ApiError ? err.message : 'Gagal memuat data absensi', 'error');
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedMeeting]);

  const filteredMembers = useMemo(() => {
    return members.filter((m) => {
      if (category && m.kategori !== category) return false;
      if (search && !m.nama_lengkap.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [members, category, search]);

  async function tapStatus(memberId: string, status: AttendanceStatus) {
    if (!selectedMeeting) return;
    const prev = records[memberId];
    setRecords((r) => ({ ...r, [memberId]: status })); // optimistic
    try {
      await attendanceApi.save({ meeting_id: selectedMeeting.meeting_id, member_id: memberId, status });
      showToast('Tersimpan');
    } catch (err) {
      setRecords((r) => ({ ...r, [memberId]: prev as AttendanceStatus }));
      showToast(err instanceof ApiError ? err.message : 'Gagal menyimpan absensi', 'error');
    }
  }

  return (
    <AppLayout>
      <Header title="Absensi" subtitle={selectedMeeting ? formatDateLong(selectedMeeting.tanggal) : undefined} />

      <div className="px-4 pt-3 pb-2">
        {meetings.length > 0 ? (
          <select
            value={selectedMeeting?.meeting_id || ''}
            onChange={(e) => setSelectedMeeting(meetings.find((m) => m.meeting_id === e.target.value) || null)}
            className="w-full min-h-[44px] rounded-xl border-none bg-surface-card2 shadow-neu-pressed-sm px-3.5 text-[16px] text-surface-text focus:outline-none"
          >
            {meetings.map((m) => (
              <option key={m.meeting_id} value={m.meeting_id}>
                {m.hari}, {m.tanggal} — {m.acara || 'Pengajian'}
              </option>
            ))}
          </select>
        ) : (
          !loading && <p className="text-sm text-surface-muted">Belum ada jadwal pengajian.</p>
        )}
        {isAdminLike || role === 'TIM_ABSENSI' ? (
          <button onClick={() => setCreateOpen(true)} className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-accent">
            <Plus size={14} /> Buat jadwal pengajian baru
          </button>
        ) : null}
      </div>

      {selectedMeeting && (
        <>
          <div className="px-4 pb-2">
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-muted" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Cari jamaah"
                className="w-full min-h-[36px] rounded-xl border-none bg-surface-card2 shadow-neu-pressed-sm pl-9 pr-3.5 text-[16px] text-surface-text placeholder:text-surface-muted focus:outline-none"
              />
            </div>
          </div>
          <div className="px-4 pb-2 flex gap-2 overflow-x-auto no-scrollbar">
            <CategoryChip active={category === ''} label="Semua" onClick={() => setCategory('')} />
            {MEMBER_CATEGORIES.map((c) => (
              <CategoryChip key={c} active={category === c} label={CATEGORY_LABEL[c]} onClick={() => setCategory(c)} />
            ))}
          </div>

          <div className="px-4 py-2 space-y-2">
            {loading && <LoadingState />}
            {!loading && filteredMembers.length === 0 && <EmptyState title="Tidak ada jamaah" />}
            {!loading &&
              filteredMembers.map((m) => (
                <Card key={m.member_id} className="flex items-center justify-between gap-2">
                  <p className="font-medium text-sm text-surface-text flex-1 min-w-0 truncate">{m.nama_lengkap}</p>
                  <div className="flex gap-1.5 flex-shrink-0">
                    {ATTENDANCE_STATUSES.map((s) => (
                      <button
                        key={s}
                        onClick={() => tapStatus(m.member_id, s)}
                        className={`neu-press min-h-[32px] px-2.5 rounded-lg text-[11px] font-semibold transition-shadow ${
                          records[m.member_id] === s ? `${STATUS_STYLE[s]} shadow-neu-sm` : 'bg-surface-card2 text-surface-muted shadow-neu-pressed-sm'
                        }`}
                      >
                        {ATTENDANCE_LABEL[s]}
                      </button>
                    ))}
                  </div>
                </Card>
              ))}
          </div>
        </>
      )}

      <CreateMeetingSheet open={createOpen} onClose={() => setCreateOpen(false)} onCreated={(m) => { setMeetings((prev) => [m, ...prev]); setSelectedMeeting(m); }} />
    </AppLayout>
  );
}

function CategoryChip({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`neu-press whitespace-nowrap px-3.5 py-1.5 rounded-full text-ios-footnote font-medium ${
        active ? 'bg-accent text-white shadow-neu-sm' : 'bg-surface-card2 text-surface-text/80 shadow-neu-pressed-sm'
      }`}
    >
      {label}
    </button>
  );
}

function CreateMeetingSheet({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: (m: Meeting) => void }) {
  const { showToast } = useToast();
  const [groups, setGroups] = useState<Group[]>([]);
  const [tanggal, setTanggal] = useState(new Date().toISOString().slice(0, 10));
  const [jam, setJam] = useState('Isya di tempat');
  const [groupId, setGroupId] = useState('');
  const [acara, setAcara] = useState('Sambung Kelompok');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) groupApi.list().then(setGroups).catch(() => {});
  }, [open]);

  async function handleCreate() {
    setSaving(true);
    try {
      const meeting = await meetingApi.create({ tanggal, jam, group_id: groupId, acara });
      showToast('Jadwal pengajian dibuat');
      onCreated(meeting);
      onClose();
    } catch (err) {
      showToast(err instanceof ApiError ? err.message : 'Gagal membuat jadwal', 'error');
    } finally {
      setSaving(false);
    }
  }

  return (
    <BottomSheet open={open} onClose={onClose} title="Jadwal Pengajian Baru">
      <Input label="Tanggal" type="date" value={tanggal} onChange={(e) => setTanggal(e.target.value)} />
      <p className="text-xs text-surface-muted -mt-3 mb-4">Hari: {getHariFromDate(tanggal)}</p>
      <Select label="Kelompok" value={groupId} onChange={(e) => setGroupId(e.target.value)}>
        <option value="">Pilih kelompok</option>
        {groups.map((g) => <option key={g.group_id} value={g.group_id}>{g.group_name}</option>)}
      </Select>
      <Input label="Jam" value={jam} onChange={(e) => setJam(e.target.value)} />
      <Input label="Acara" value={acara} onChange={(e) => setAcara(e.target.value)} />
      <Button fullWidth onClick={handleCreate} disabled={saving}>{saving ? 'Menyimpan...' : 'Buat Jadwal'}</Button>
    </BottomSheet>
  );
}
