import { useEffect, useState } from 'react';
import { AppLayout, Header, FloatingActionButton } from '../components/layout/AppLayout';
import { Badge, Button, Input, Select, BottomSheet, LoadingState, GroupedList, ListRow } from '../components/common';
import { userApi } from '../services/domainApi';
import type { Role, User } from '../types';
import { useToast } from '../contexts/ToastContext';
import { ApiError } from '../services/api';

const ROLE_LABEL: Record<Role, string> = {
  SUPER_ADMIN: 'Super Admin', ADMIN: 'Admin', TIM_PNKB: 'Tim PNKB', TIM_ABSENSI: 'Tim Absensi'
};

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const { showToast } = useToast();

  async function load() {
    setLoading(true);
    try {
      setUsers(await userApi.list());
    } catch (err) {
      showToast(err instanceof ApiError ? err.message : 'Gagal memuat user', 'error');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  return (
    <AppLayout hideNav>
      <Header title="Manajemen User" onBack={() => history.back()} backLabel="Lainnya" />
      <div className="py-3">
        {loading && <LoadingState />}
        {!loading && users.length > 0 && (
          <GroupedList>
            {users.map((u, i) => (
              <ListRow key={u.user_id} insetDivider={i !== users.length - 1}>
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-ios-body font-medium text-surface-text truncate">{u.nama}</p>
                    <p className="text-ios-footnote text-surface-muted truncate">@{u.username}</p>
                  </div>
                  <Badge>{ROLE_LABEL[u.role]}</Badge>
                </div>
              </ListRow>
            ))}
          </GroupedList>
        )}
      </div>
      <FloatingActionButton onClick={() => setOpen(true)} />
      <CreateUserSheet open={open} onClose={() => setOpen(false)} onCreated={load} />
    </AppLayout>
  );
}

function CreateUserSheet({ open, onClose, onCreated }: { open: boolean; onClose: () => void; onCreated: () => void }) {
  const [username, setUsername] = useState('');
  const [nama, setNama] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<Role>('TIM_ABSENSI');
  const [saving, setSaving] = useState(false);
  const { showToast } = useToast();

  async function handleCreate() {
    setSaving(true);
    try {
      await userApi.create({ username, nama, password, role });
      showToast('User dibuat');
      onCreated();
      onClose();
      setUsername(''); setNama(''); setPassword('');
    } catch (err) {
      showToast(err instanceof ApiError ? err.message : 'Gagal membuat user', 'error');
    } finally {
      setSaving(false);
    }
  }

  return (
    <BottomSheet open={open} onClose={onClose} title="User Baru">
      <Input label="Nama" value={nama} onChange={(e) => setNama(e.target.value)} />
      <Input label="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
      <Input label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <Select label="Role" value={role} onChange={(e) => setRole(e.target.value as Role)}>
        {Object.entries(ROLE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
      </Select>
      <Button fullWidth onClick={handleCreate} disabled={saving || !username || !password}>
        {saving ? 'Menyimpan...' : 'Buat User'}
      </Button>
    </BottomSheet>
  );
}
