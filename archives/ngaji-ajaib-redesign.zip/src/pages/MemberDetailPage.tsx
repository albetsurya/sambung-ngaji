import { useEffect, useState, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { AppLayout, Header } from '../components/layout/AppLayout';
import { Avatar, Button, LoadingState, ErrorState } from '../components/common';
import { memberApi } from '../services/memberApi';
import { attendanceApi, monitoringApi } from '../services/domainApi';
import type { Member, MonitoringEntry, AttendanceRecord } from '../types';
import { CATEGORY_LABEL } from '../utils/format';
import { BiodataTab, EducationTab, TimelineTab, CategoryHeaderBadge, type TimelineEvent } from '../components/member/MemberTabs';
import { MonitoringTab } from '../components/monitoring/MonitoringTab';
import { usePermission } from '../hooks/usePermission';
import { ATTENDANCE_LABEL } from '../utils/format';
import { ApiError } from '../services/api';

const TABS = ['Biodata', 'Pendidikan', 'Kehadiran', 'Monitoring'] as const;
type Tab = (typeof TABS)[number];

export default function MemberDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAdminLike, role } = usePermission();
  const [member, setMember] = useState<Member | null>(null);
  const [monitoring, setMonitoring] = useState<MonitoringEntry[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [tab, setTab] = useState<Tab>('Biodata');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError('');
    try {
      const [m, mon, att] = await Promise.all([
        memberApi.detail(id),
        monitoringApi.list(id).catch(() => []),
        attendanceApi.byMember(id).catch(() => [])
      ]);
      setMember(m);
      setMonitoring(mon);
      setAttendance(att);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Gagal memuat data jamaah');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) return <AppLayout><Header title="Jamaah" onBack={() => navigate(-1)} /><LoadingState /></AppLayout>;
  if (error || !member) return <AppLayout><Header title="Jamaah" onBack={() => navigate(-1)} /><ErrorState message={error || 'Data tidak ditemukan'} onRetry={load} /></AppLayout>;

  const timelineEvents: TimelineEvent[] = [
    ...attendance.map((a) => ({
      date: a.attendance_id, // fallback; real date resolved via meeting elsewhere, keep simple ordering by created
      type: 'attendance' as const,
      label: a.status === 'HADIR' ? 'Hadir pengajian' : `Tidak hadir (${ATTENDANCE_LABEL[a.status]})`,
      variant: (a.status === 'HADIR' ? 'success' : 'danger') as TimelineEvent['variant']
    })),
    ...monitoring.map((m) => ({
      date: m.tanggal,
      type: 'monitoring' as const,
      label: 'Monitoring',
      detail: m.catatan,
      variant: 'warning' as TimelineEvent['variant']
    }))
  ]
    .filter((e) => e.type === 'monitoring') // hanya monitoring yang punya tanggal andal tanpa join meeting tambahan
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const hadirCount = attendance.filter((a) => a.status === 'HADIR').length;
  const persentase = attendance.length ? Math.round((hadirCount / attendance.length) * 100) : 0;

  return (
    <AppLayout hideNav>
      <Header
        title={member.nama_lengkap}
        onBack={() => navigate(-1)}
        right={isAdminLike ? (
          <button onClick={() => navigate(`/jamaah/${member.member_id}/edit`)} className="ios-active text-ios-body font-semibold text-accent">
            Edit
          </button>
        ) : undefined}
      />

      <div className="px-4 pt-4 pb-3 flex items-center gap-3">
        <Avatar src={member.foto_url} name={member.nama_lengkap} size={64} />
        <div className="min-w-0">
          <p className="text-[19px] font-semibold text-surface-text truncate">{member.nama_lengkap}</p>
          <div className="flex items-center gap-2 mt-1">
            <CategoryHeaderBadge member={member} />
            <span className="text-ios-footnote text-surface-muted truncate">{member.kelompok}</span>
          </div>
        </div>
      </div>

      <div
        className="px-3 flex gap-1 sticky backdrop-blur-ios bg-surface-bg/90 shadow-neu-bar-bottom z-10"
        style={{ top: 'calc(44px + var(--safe-top))' }}
      >
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`ios-active px-2.5 py-2.5 text-ios-subhead font-medium border-b-2 -mb-px ${
              tab === t ? 'border-accent text-accent' : 'border-transparent text-surface-muted'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="px-4 py-4">
        {tab === 'Biodata' && <BiodataTab member={member} />}
        {tab === 'Pendidikan' && <EducationTab education={member.pendidikan || []} />}
        {tab === 'Kehadiran' && (
          <div className="space-y-3">
            <div className="grid grid-cols-4 gap-2 text-center">
              <StatBox label="Hadir" value={attendance.filter((a) => a.status === 'HADIR').length} />
              <StatBox label="Ijin" value={attendance.filter((a) => a.status === 'IJIN').length} />
              <StatBox label="Sakit" value={attendance.filter((a) => a.status === 'SAKIT').length} />
              <StatBox label="Alpa" value={attendance.filter((a) => a.status === 'TANPA_KETERANGAN').length} />
            </div>
            <p className="text-ios-subhead text-surface-text/80 text-center">Persentase hadir: <strong>{persentase}%</strong></p>
            <TimelineTab events={timelineEvents} />
          </div>
        )}
        {tab === 'Monitoring' && (
          <MonitoringTab
            memberId={member.member_id}
            entries={monitoring}
            canWrite={isAdminLike || role === 'TIM_PNKB'}
            onSaved={load}
          />
        )}
      </div>
    </AppLayout>
  );
}

function StatBox({ label, value }: { label: string; value: number }) {
  return (
    <div className="bg-surface-card2 shadow-neu-pressed-sm rounded-xl py-2.5">
      <p className="text-[19px] font-semibold text-surface-text">{value}</p>
      <p className="text-ios-caption text-surface-muted">{label}</p>
    </div>
  );
}
