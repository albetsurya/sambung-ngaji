import { useEffect, useState, type FormEvent } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Camera, Pencil } from 'lucide-react';
import { AppLayout, Header } from '../components/layout/AppLayout';
import { Button, Input, Select, Textarea, LoadingState } from '../components/common';
import { memberApi } from '../services/memberApi';
import { uploadApi } from '../services/domainApi';
import { groupApi } from '../services/domainApi';
import type { Group, Member } from '../types';
import { getMemberCategory, normalizePhoneNumber } from '../utils/format';
import { useToast } from '../contexts/ToastContext';
import { ApiError } from '../services/api';

const emptyForm: Partial<Member> = {
  nama_lengkap: '', nama_panggilan: '', jenis_kelamin: 'L', tempat_lahir: '', tanggal_lahir: '',
  kelompok: '', desa: '', daerah: '', alamat_rumah: '', no_wa: '', is_nikah: false, is_kerja: false,
  is_muballigh: false, tinggi_badan: '', berat_badan: '', hobi: '', pekerjaan: ''
};

export default function MemberFormPage() {
  const { id } = useParams();
  const isEdit = !!id;
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [form, setForm] = useState<Partial<Member>>(emptyForm);
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(isEdit);
  const [submitting, setSubmitting] = useState(false);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>('');

  useEffect(() => {
    groupApi.list().then(setGroups).catch(() => {});
    if (isEdit && id) {
      memberApi.detail(id).then((m) => {
        setForm(m);
        setPhotoPreview(m.foto_url || '');
        setLoading(false);
      }).catch(() => setLoading(false));
    }
  }, [id, isEdit]);

  const previewCategory = getMemberCategory(form);

  function update<K extends keyof Member>(key: K, value: Member[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      showToast('Foto harus berformat JPEG/PNG/WEBP', 'error');
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      showToast('Ukuran foto maksimum 5MB', 'error');
      return;
    }
    setPhotoFile(file);
    setPhotoPreview(URL.createObjectURL(file));
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = { ...form, no_wa: form.no_wa ? normalizePhoneNumber(form.no_wa) : '' };
      let memberId = id;
      if (isEdit && id) {
        await memberApi.update(id, payload);
      } else {
        const created = await memberApi.create(payload);
        memberId = created.member_id;
      }
      if (photoFile && memberId) {
        const base64 = await fileToBase64(photoFile);
        await uploadApi.photo(memberId, base64, photoFile.type);
      }
      showToast(isEdit ? 'Data jamaah diperbarui' : 'Jamaah baru ditambahkan');
      navigate(memberId ? `/jamaah/${memberId}` : '/jamaah');
    } catch (err) {
      showToast(err instanceof ApiError ? err.message : 'Gagal menyimpan data', 'error');
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) return <AppLayout><LoadingState /></AppLayout>;

  return (
    <AppLayout hideNav>
      <Header title={isEdit ? 'Edit Jamaah' : 'Tambah Jamaah'} onBack={() => navigate(-1)} />
      <form onSubmit={handleSubmit} className="px-4 py-4 pb-10">
        <div className="flex flex-col items-center mb-5">
          <label className="relative cursor-pointer">
            <div className="w-24 h-24 rounded-full bg-surface-card2 shadow-neu-pressed overflow-hidden flex items-center justify-center text-3xl">
              {photoPreview ? <img src={photoPreview} alt="Foto" className="w-full h-full object-cover" /> : <Camera size={26} className="text-accent" />}
            </div>
            <input type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handlePhotoChange} />
            <span className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-accent text-white shadow-neu-sm flex items-center justify-center">
              <Pencil size={13} />
            </span>
          </label>
          {previewCategory && (
            <span className="mt-3 text-ios-footnote font-medium text-accent bg-accent-soft px-3 py-1 rounded-full">
              Kategori otomatis: {previewCategory}
            </span>
          )}
        </div>

        <Input label="Nama Lengkap" required value={form.nama_lengkap || ''} onChange={(e) => update('nama_lengkap', e.target.value)} />
        <Input label="Nama Panggilan" value={form.nama_panggilan || ''} onChange={(e) => update('nama_panggilan', e.target.value)} />
        <Select label="Jenis Kelamin" value={form.jenis_kelamin || 'L'} onChange={(e) => update('jenis_kelamin', e.target.value as Member['jenis_kelamin'])}>
          <option value="L">Laki-laki</option>
          <option value="P">Perempuan</option>
        </Select>
        <div className="grid grid-cols-2 gap-3">
          <Input label="Tempat Lahir" value={form.tempat_lahir || ''} onChange={(e) => update('tempat_lahir', e.target.value)} />
          <Input label="Tanggal Lahir" type="date" value={form.tanggal_lahir || ''} onChange={(e) => update('tanggal_lahir', e.target.value)} />
        </div>
        <Select label="Kelompok" value={form.kelompok || ''} onChange={(e) => update('kelompok', e.target.value)}>
          <option value="">Pilih kelompok</option>
          {groups.map((g) => <option key={g.group_id} value={g.group_id}>{g.group_name}</option>)}
        </Select>
        <div className="grid grid-cols-2 gap-3">
          <Input label="Desa" value={form.desa || ''} onChange={(e) => update('desa', e.target.value)} />
          <Input label="Daerah" value={form.daerah || ''} onChange={(e) => update('daerah', e.target.value)} />
        </div>
        <Textarea label="Alamat Rumah" value={form.alamat_rumah || ''} onChange={(e) => update('alamat_rumah', e.target.value)} />
        <Input label="No. WhatsApp" placeholder="0812xxxxxxxx" value={form.no_wa || ''} onChange={(e) => update('no_wa', e.target.value)} />

        <label className="flex items-center gap-2 mb-4 min-h-[44px]">
          <input type="checkbox" className="w-5 h-5 accent-accent" checked={!!form.is_nikah} onChange={(e) => update('is_nikah', e.target.checked)} />
          <span className="text-ios-body text-surface-text">Sudah menikah</span>
        </label>

        {!form.is_nikah && (
          <>
            <h3 className="text-ios-body font-semibold text-surface-text mb-2 mt-2">Data Tambahan (Pra Nikah)</h3>
            <div className="grid grid-cols-2 gap-3">
              <Input label="Tinggi Badan (cm)" type="number" value={form.tinggi_badan || ''} onChange={(e) => update('tinggi_badan', e.target.value)} />
              <Input label="Berat Badan (kg)" type="number" value={form.berat_badan || ''} onChange={(e) => update('berat_badan', e.target.value)} />
            </div>
            <Input label="Hobi" value={form.hobi || ''} onChange={(e) => update('hobi', e.target.value)} />
          </>
        )}

        <Input label="Pekerjaan" value={form.pekerjaan || ''} onChange={(e) => update('pekerjaan', e.target.value)} />

        <label className="flex items-center gap-2 mb-4 min-h-[44px]">
          <input type="checkbox" className="w-5 h-5 accent-accent" checked={!!form.is_muballigh} onChange={(e) => update('is_muballigh', e.target.checked)} />
          <span className="text-ios-body text-surface-text">Muballigh</span>
        </label>

        <Button type="submit" fullWidth disabled={submitting}>
          {submitting ? 'Menyimpan...' : 'Simpan'}
        </Button>
      </form>
    </AppLayout>
  );
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1]);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
