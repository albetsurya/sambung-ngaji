import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, TrendingUp, AlertTriangle, FileWarning, KeyRound, Calendar,
  Heart, CheckCircle2, ClipboardList, Thermometer, CircleAlert, ArrowUpRight,
  ChevronRight, Sun, Moon, type LucideIcon
} from 'lucide-react';
import { AppLayout } from '../components/layout/AppLayout';
import { Card, Avatar, LoadingState, ErrorState } from '../components/common';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { dashboardApi } from '../services/domainApi';
import { CATEGORY_LABEL } from '../utils/format';
import type { DashboardAbsensi, DashboardGeneral, DashboardPNKB } from '../types';
import { ApiError } from '../services/api';

type IconType = LucideIcon;

export default function DashboardPage() {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [data, setData] = useState<DashboardGeneral | DashboardPNKB | DashboardAbsensi | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    setError('');
    try {
      const res = await dashboardApi.general();
      setData(res as any);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Gagal memuat dashboard');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const hour = new Date().getHours();
  const greeting = hour < 11 ? 'Selamat pagi' : hour < 15 ? 'Selamat siang' : hour < 18 ? 'Selamat sore' : 'Selamat malam';

  return (
    <AppLayout>
      <div className="app-shell sticky top-0 z-30 border-b border-surface-border backdrop-blur-ios bg-surface-bg/95 shadow-neu-bar-bottom pt-safe">
        <div className="flex items-center justify-between px-4 py-3">
          <div>
            <p className="text-ios-footnote text-surface-muted">{greeting},</p>
            <h1 className="text-[19px] font-semibold text-surface-text leading-tight">{user?.nama}</h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              aria-label="Ganti mode tampilan"
              className="ios-active w-9 h-9 flex items-center justify-center rounded-xl bg-surface-card border border-surface-border shadow-card text-surface-text"
            >
              {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            <Avatar name={user?.nama || '?'} size={40} />
          </div>
        </div>
      </div>

      <div className="px-4 py-4 space-y-3">
        {loading && <LoadingState />}
        {!loading && error && <ErrorState message={error} onRetry={load} />}
        {!loading && !error && data && user?.role === 'TIM_PNKB' && <PNKBDashboard data={data as DashboardPNKB} />}
        {!loading && !error && data && user?.role === 'TIM_ABSENSI' && <AbsensiDashboard data={data as DashboardAbsensi} />}
        {!loading && !error && data && (user?.role === 'SUPER_ADMIN' || user?.role === 'ADMIN') && (
          <GeneralDashboard data={data as DashboardGeneral} isSuperAdmin={user.role === 'SUPER_ADMIN'} />
        )}
      </div>
    </AppLayout>
  );
}

function SectionHeader({ title, onSeeAll }: { title: string; onSeeAll?: () => void }) {
  return (
    <div className="flex items-center justify-between px-0.5 pt-1">
      <h2 className="font-display text-base text-surface-text">{title}</h2>
      {onSeeAll && (
        <button onClick={onSeeAll} className="text-xs font-medium text-accent">
          Lihat semua
        </button>
      )}
    </div>
  );
}

function HeroStatCard({ label, value, footer, Icon }: { label: string; value: string | number; footer?: string; Icon: IconType }) {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-accent text-white shadow-card p-5">
      <div className="flex items-start justify-between">
        <p className="text-xs text-white/80">{label}</p>
        <span className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center">
          <Icon size={17} className="text-white" />
        </span>
      </div>
      <div className="flex items-baseline gap-2 mt-2">
        <span className="font-display text-3xl font-bold text-white tabular-nums">{value}</span>
      </div>
      {footer && (
        <p className="text-xs text-white/80 mt-2 flex items-center gap-1">
          <ArrowUpRight size={13} className="text-white" /> {footer}
        </p>
      )}
    </div>
  );
}

function StatTile({ label, value, color, Icon }: { label: string; value: string | number; color?: string; Icon: IconType }) {
  return (
    <Card className="flex-1">
      <div className="flex items-start justify-between mb-2">
        <p className="text-xs text-white/80">{label}</p>
        <Icon size={16} className="text-surface-muted opacity-80" />
      </div>
      <p className={`font-display text-2xl ${color || 'text-surface-text'}`}>{value}</p>
    </Card>
  );
}

function MeetingCard({ meeting, onClick }: { meeting: { meeting_id: string; tanggal: string; hari: string; acara?: string; jam?: string }; onClick?: () => void }) {
  const dateNum = new Date(meeting.tanggal).getDate();
  return (
    <Card onClick={onClick} className="flex items-center gap-3">
      <div className="w-11 h-11 rounded-xl bg-surface-card2 shadow-neu-pressed-sm flex flex-col items-center justify-center flex-shrink-0">
        <Calendar size={12} className="text-accent" />
        <span className="text-sm font-bold text-accent leading-none mt-0.5">{dateNum}</span>
      </div>
      <div className="flex-1 min-w-0">
        <span className="inline-block text-[10px] font-bold tracking-wide text-accent bg-accent-soft rounded-full px-2 py-0.5 mb-1 uppercase">
          {meeting.hari}
        </span>
        <p className="font-medium text-sm text-surface-text truncate">{meeting.acara || 'Pengajian'}</p>
        <p className="text-xs text-surface-muted truncate">{[meeting.jam].filter(Boolean).join(' · ')}</p>
      </div>
      <ChevronRight size={18} className="text-surface-muted flex-shrink-0" />
    </Card>
  );
}

function AttentionListSection({ items }: { items: { member_id: string; nama_lengkap: string; foto_url?: string; reasons: string[] }[] }) {
  const navigate = useNavigate();
  if (!items.length) return null;
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between px-0.5 pt-1">
        <h2 className="flex items-center gap-1.5 font-display text-base text-surface-text">
          <AlertTriangle size={16} className="text-warning" /> Perlu Perhatian
        </h2>
        <button onClick={() => navigate('/jamaah')} className="text-xs font-medium text-accent">Lihat semua</button>
      </div>
      <div className="space-y-2">
        {items.map((m) => (
          <Card key={m.member_id} onClick={() => navigate(`/jamaah/${m.member_id}`)} className="flex items-center gap-3">
            <Avatar src={m.foto_url} name={m.nama_lengkap} />
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm text-surface-text truncate">{m.nama_lengkap}</p>
              <p className="text-xs text-warning truncate">{m.reasons[0]}</p>
            </div>
            <ChevronRight size={18} className="text-surface-muted flex-shrink-0" />
          </Card>
        ))}
      </div>
    </div>
  );
}

function GeneralDashboard({ data, isSuperAdmin }: { data: DashboardGeneral; isSuperAdmin: boolean }) {
  const navigate = useNavigate();
  return (
    <>
      <HeroStatCard label="Total Jamaah Aktif" value={data.total_jamaah} footer="Data diperbarui hari ini" Icon={Users} />

      <div className="flex gap-3">
        <StatTile label="Kehadiran" value={`${data.rata_rata_kehadiran}%`} color="text-accent" Icon={TrendingUp} />
        <StatTile label="Perlu Perhatian" value={data.jamaah_perlu_perhatian.length} color="text-warning" Icon={AlertTriangle} />
      </div>

      {isSuperAdmin && (
        <div className="flex gap-3">
          <StatTile label="Data Belum Lengkap" value={data.data_belum_lengkap} color="text-warning" Icon={FileWarning} />
          <StatTile label="User Aktif" value={data.user_aktif ?? '-'} Icon={KeyRound} />
        </div>
      )}

      <Card>
        <p className="text-xs text-surface-muted mb-2">Jamaah per Kategori</p>
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(data.per_kategori).map(([k, v]) => (
            <div key={k} className="flex items-center justify-between bg-surface-card2 shadow-neu-pressed-sm rounded-xl px-3 py-2">
              <span className="text-sm text-surface-text/90">{CATEGORY_LABEL[k as keyof typeof CATEGORY_LABEL]}</span>
              <span className="text-xs font-semibold text-accent bg-accent-soft rounded-full px-2 py-0.5">{v}</span>
            </div>
          ))}
        </div>
      </Card>

      {data.pengajian_terdekat && (
        <div className="space-y-2">
          <SectionHeader title="Pengajian Terdekat" onSeeAll={() => navigate('/absensi')} />
          <MeetingCard meeting={data.pengajian_terdekat} onClick={() => navigate('/absensi')} />
        </div>
      )}

      <AttentionListSection items={data.jamaah_perlu_perhatian} />
    </>
  );
}

function PNKBDashboard({ data }: { data: DashboardPNKB }) {
  return (
    <>
      <HeroStatCard label="Jamaah Pra Nikah" value={data.total} footer={`${data.aktif} aktif dalam pembinaan`} Icon={Heart} />
      <div className="flex gap-3">
        <StatTile label="Perlu Perhatian" value={data.perlu_perhatian} color="text-warning" Icon={AlertTriangle} />
        <StatTile label="Kehadiran" value={`${data.kehadiran}%`} color="text-accent" Icon={TrendingUp} />
      </div>
      <StatTile label="Data Belum Lengkap" value={data.data_belum_lengkap} Icon={FileWarning} />
    </>
  );
}

function AbsensiDashboard({ data }: { data: DashboardAbsensi }) {
  const navigate = useNavigate();
  return (
    <>
      <HeroStatCard label="Jamaah Diabsen Hari Ini" value={data.jumlah_jamaah} footer={`${data.hadir} hadir`} Icon={CheckCircle2} />

      <SectionHeader title="Pengajian Hari Ini" onSeeAll={() => navigate('/absensi')} />
      {data.pengajian_hari_ini.length === 0 && (
        <Card><p className="text-sm text-surface-muted">Tidak ada jadwal pengajian hari ini.</p></Card>
      )}
      {data.pengajian_hari_ini.map((m) => (
        <MeetingCard
          key={m.meeting_id}
          meeting={{ meeting_id: m.meeting_id, tanggal: new Date().toISOString(), hari: 'Hari Ini', acara: m.acara, jam: m.jam }}
          onClick={() => navigate('/absensi')}
        />
      ))}

      <div className="flex gap-3">
        <StatTile label="Ijin" value={data.ijin} Icon={ClipboardList} />
        <StatTile label="Sakit" value={data.sakit} Icon={Thermometer} />
        <StatTile label="Tanpa Ket." value={data.tanpa_keterangan} color="text-danger" Icon={CircleAlert} />
      </div>
    </>
  );
}
