import { NavLink } from 'react-router-dom';
import { Home, Users, CalendarCheck, Megaphone, MoreHorizontal } from 'lucide-react';
import { usePermission } from '../../hooks/usePermission';

const ITEMS = [
  { key: 'beranda', to: '/', icon: Home, label: 'Beranda' },
  { key: 'jamaah', to: '/jamaah', icon: Users, label: 'Jamaah' },
  { key: 'absensi', to: '/absensi', icon: CalendarCheck, label: 'Absensi' },
  { key: 'pengumuman', to: '/pengumuman', icon: Megaphone, label: 'Pengumuman' },
  { key: 'lainnya', to: '/lainnya', icon: MoreHorizontal, label: 'Lainnya' }
];

export function BottomNav() {
  const { canSeeNav } = usePermission();
  const visible = ITEMS.filter((i) => canSeeNav(i.key));

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-surface-border bg-surface-card/95 backdrop-blur-ios shadow-neu-bar-top pb-safe">
      <div className="app-shell grid px-2 py-1" style={{ gridTemplateColumns: `repeat(${visible.length}, 1fr)` }}>
        {visible.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink key={item.key} to={item.to} end={item.to === '/'} className="ios-active flex flex-col items-center justify-center gap-0.5 py-1 h-[48px] mx-1 rounded-xl">
              {({ isActive }) => (
                <>
                  <Icon size={22} strokeWidth={isActive ? 2.25 : 1.8} className={isActive ? 'text-accent' : 'text-surface-muted'} />
                  <span className={`text-ios-tab ${isActive ? 'text-accent font-semibold' : 'text-surface-muted'}`}>{item.label}</span>
                </>
              )}
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}
