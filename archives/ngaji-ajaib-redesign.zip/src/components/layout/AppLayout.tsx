import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Plus, Sun, Moon } from 'lucide-react';
import { BottomNav } from './BottomNav';
import { useTheme } from '../../contexts/ThemeContext';

interface HeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  /** Label tombol kembali khas iOS, mis. judul halaman sebelumnya (opsional) */
  backLabel?: string;
  right?: ReactNode;
  /** Tampilkan tombol beralih mode gelap/terang di sisi kanan header (default: false) */
  showThemeToggle?: boolean;
}

/**
 * Header ala iOS Navigation Bar: translucent + blur, judul rata tengah,
 * tombol back berupa chevron aksen, aksi kanan berupa teks/ikon aksen.
 * Kolom kiri & kanan diberi lebar minimum yang sama agar judul benar-benar
 * center secara visual, persis seperti UINavigationBar.
 */
export function Header({ title, subtitle, onBack, backLabel, right, showThemeToggle }: HeaderProps) {
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="sticky top-0 z-30 pt-safe border-b border-surface-border backdrop-blur-ios bg-surface-bg/95 shadow-neu-bar-bottom">
      <div className="app-shell flex items-stretch h-[44px] px-1">
        {/* Kolom kiri */}
        <div className="flex items-center min-w-[44px] flex-1 basis-0">
          {onBack && (
            <button
              onClick={() => (onBack ? onBack() : navigate(-1))}
              className="ios-active flex items-center gap-0.5 pl-1 pr-2 h-full text-accent"
            >
              <ChevronLeft size={26} strokeWidth={2.2} className="-ml-1.5 shrink-0" />
              {backLabel && <span className="text-ios-body truncate max-w-[110px]">{backLabel}</span>}
            </button>
          )}
        </div>

        {/* Judul — selalu di tengah */}
        <div className="flex flex-col items-center justify-center px-1 shrink-0 max-w-[56%]">
          <h1 className="text-ios-nav text-surface-text truncate">{title}</h1>
          {subtitle && <p className="text-ios-caption text-surface-muted truncate">{subtitle}</p>}
        </div>

        {/* Kolom kanan */}
        <div className="flex items-center justify-end gap-1 min-w-[44px] flex-1 basis-0">
          {showThemeToggle && (
            <button
              onClick={toggleTheme}
              aria-label="Ganti mode tampilan"
              className="ios-active w-9 h-9 flex items-center justify-center rounded-xl bg-surface-card border border-surface-border shadow-card text-surface-text"
            >
              {theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />}
            </button>
          )}
          {right}
        </div>
      </div>
    </header>
  );
}

export function AppLayout({ children, hideNav }: { children: ReactNode; hideNav?: boolean }) {
  return (
    <div className="app-shell min-h-screen bg-surface-bg flex flex-col">
      <div className={`flex-1 ${hideNav ? '' : 'pb-24'}`}>{children}</div>
      {!hideNav && <BottomNav />}
    </div>
  );
}

export function FloatingActionButton({ onClick, label = 'Tambah' }: { onClick: () => void; label?: string }) {
  return (
    <button
      onClick={onClick}
      className="neu-press fixed z-40 right-4 w-14 h-14 rounded-full bg-accent text-white shadow-neu-float flex items-center justify-center active:scale-95"
      style={{ bottom: 'calc(76px + var(--safe-bottom))' }}
      aria-label={label}
    >
      <Plus size={26} strokeWidth={2.5} />
    </button>
  );
}
