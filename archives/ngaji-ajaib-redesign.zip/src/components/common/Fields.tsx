import type { InputHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes, ReactNode } from 'react';

interface FieldWrapProps {
  label?: string;
  children: ReactNode;
  hint?: string;
}

function FieldWrap({ label, children, hint }: FieldWrapProps) {
  return (
    <label className="block mb-4">
      {label && <span className="block text-ios-footnote font-medium text-surface-muted mb-1.5 px-0.5">{label}</span>}
      {children}
      {hint && <span className="block text-ios-caption text-surface-muted mt-1.5 px-0.5">{hint}</span>}
    </label>
  );
}

/**
 * Input neumorphic: alih-alih outline atau latar abu datar, field terlihat
 * "terukir" ke dalam permukaan (inset shadow) — sinyal visual bahwa area
 * ini bisa diisi, tanpa border keras. Fokus memperjelas cekungan itu.
 */
const baseInputClasses =
  'w-full min-h-[44px] rounded-2xl border-none bg-surface-card2 shadow-neu-pressed-sm px-3.5 text-[16px] text-surface-text placeholder:text-surface-muted focus:outline-none focus:ring-2 focus:ring-accent/40 transition-shadow';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
}
export function Input({ label, hint, className = '', ...rest }: InputProps) {
  return (
    <FieldWrap label={label} hint={hint}>
      <input className={`${baseInputClasses} ${className}`} {...rest} />
    </FieldWrap>
  );
}

interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  hint?: string;
}
export function Select({ label, hint, className = '', children, ...rest }: SelectProps) {
  return (
    <FieldWrap label={label} hint={hint}>
      <select className={`${baseInputClasses} ${className}`} {...rest}>
        {children}
      </select>
    </FieldWrap>
  );
}

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  hint?: string;
}
export function Textarea({ label, hint, className = '', ...rest }: TextareaProps) {
  return (
    <FieldWrap label={label} hint={hint}>
      <textarea className={`${baseInputClasses} py-3 min-h-[96px] ${className}`} {...rest} />
    </FieldWrap>
  );
}
