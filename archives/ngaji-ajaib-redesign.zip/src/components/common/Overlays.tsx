import { X } from 'lucide-react';
import type { ReactNode } from 'react';

interface SheetProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}

/** Bottom sheet ala iOS/WhatsApp: drag handle, sudut membulat besar, slide-up. */
export function BottomSheet({ open, onClose, title, children }: SheetProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div className="absolute inset-0 bg-black/40 animate-[fadeIn_0.2s_ease-out]" onClick={onClose} />
      <div className="app-shell relative w-full bg-surface-card rounded-t-[28px] shadow-neu-float max-h-[85vh] flex flex-col animate-[sheetIn_0.28s_cubic-bezier(0.32,0.72,0,1)]">
        <div className="flex items-center justify-center pt-2 pb-1.5">
          <div className="w-9 h-[5px] rounded-full bg-surface-card2 shadow-neu-pressed-sm" />
        </div>
        {title && (
          <div className="px-5 pb-2 flex items-center justify-between">
            <h3 className="text-ios-nav text-surface-text">{title}</h3>
            <button onClick={onClose} className="neu-press text-surface-muted w-8 h-8 flex items-center justify-center rounded-full bg-surface-card2 shadow-neu-sm">
              <X size={16} />
            </button>
          </div>
        )}
        <div className="px-5 pb-[calc(1.25rem+var(--safe-bottom))] overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

/** Modal terpusat ala iOS (Card Sheet), dipakai untuk form/konten yang lebih panjang. */
export function Modal({ open, onClose, title, children }: SheetProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/40 animate-[fadeIn_0.2s_ease-out]" onClick={onClose} />
      <div className="app-shell relative w-full bg-surface-card rounded-[28px] shadow-neu-float max-h-[85vh] flex flex-col animate-[popIn_0.18s_ease-out]">
        {title && (
          <div className="px-5 pt-5 pb-2 flex items-center justify-between">
            <h3 className="text-ios-nav text-surface-text">{title}</h3>
            <button onClick={onClose} className="neu-press text-surface-muted w-8 h-8 flex items-center justify-center rounded-full bg-surface-card2 shadow-neu-sm">
              <X size={16} />
            </button>
          </div>
        )}
        <div className="px-5 pb-5 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

interface ConfirmProps {
  open: boolean;
  title: string;
  description?: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

/**
 * Dialog konfirmasi ala UIAlertController (iOS Alert): kartu kecil terpusat,
 * judul & deskripsi di tengah, tombol berdampingan dipisah garis tipis —
 * bukan tombol besar bertumpuk seperti Android.
 */
export function ConfirmDialog({ open, title, description, confirmLabel = 'Ya, lanjutkan', danger, onConfirm, onCancel }: ConfirmProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-10">
      <div className="absolute inset-0 bg-black/40 animate-[fadeIn_0.15s_ease-out]" onClick={onCancel} />
      <div className="relative w-full max-w-[270px] bg-surface-card rounded-[24px] overflow-hidden shadow-neu-float animate-[popIn_0.16s_ease-out]">
        <div className="px-4 pt-4 pb-3.5 text-center">
          <h3 className="text-[17px] font-semibold text-surface-text">{title}</h3>
          {description && <p className="text-ios-footnote text-surface-muted mt-1">{description}</p>}
        </div>
        <div className="flex gap-2.5 px-3 pb-3">
          <button
            onClick={onCancel}
            className="neu-press flex-1 h-11 rounded-2xl text-[15px] text-surface-text bg-surface-card2 shadow-neu-pressed-sm"
          >
            Batal
          </button>
          <button
            onClick={onConfirm}
            className={`neu-press flex-1 h-11 rounded-2xl text-[15px] font-semibold text-white shadow-neu-sm ${danger ? 'bg-danger' : 'bg-accent'}`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
