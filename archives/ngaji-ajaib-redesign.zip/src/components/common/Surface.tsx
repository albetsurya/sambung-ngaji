import type { ReactNode } from 'react';
import { ChevronRight } from 'lucide-react';

export function Card({ children, className = '', onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      className={`bg-surface-card rounded-2xl shadow-card p-4 ${
        onClick ? 'neu-press cursor-pointer hover:bg-surface-card2' : ''
      } ${className}`}
    >
      {children}
    </div>
  );
}

/**
 * Grouped list ala iOS Settings/WhatsApp, digambar ulang neumorphic: satu
 * panel timbul (raised) dengan bayangan ganda, baris di dalamnya dipisah
 * garis sangat tipis alih-alih border keras.
 */
export function GroupedList({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <div className={`mx-4 my-2 bg-surface-card rounded-neu overflow-hidden shadow-card ${className}`}>
      {children}
    </div>
  );
}

export function ListRow({
  children,
  onClick,
  leading,
  insetDivider = true,
  className = ''
}: {
  children: ReactNode;
  onClick?: () => void;
  /** Konten di depan baris (ikon/avatar) — dipakai untuk menghitung offset divider inset */
  leading?: ReactNode;
  insetDivider?: boolean;
  className?: string;
}) {
  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-3 min-h-[44px] px-4 py-2.5 ${insetDivider ? 'ios-list-divider' : ''} ${
        onClick ? 'ios-active active:bg-surface-card2/70 cursor-pointer' : ''
      } ${className}`}
    >
      {leading}
      <div className="flex-1 min-w-0">{children}</div>
    </div>
  );
}

export function Avatar({ src, name, size = 44 }: { src?: string; name: string; size?: number }) {
  const initials = name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((n) => n[0])
    .join('')
    .toUpperCase();
  if (src) {
    return (
      <img
        src={src}
        alt={name}
        style={{ width: size, height: size }}
        className="rounded-full object-cover bg-accent-soft shadow-none flex-shrink-0"
      />
    );
  }
  return (
    <div
      style={{ width: size, height: size }}
      className="rounded-full bg-accent-soft shadow-none text-accent flex items-center justify-center font-semibold flex-shrink-0"
    >
      {initials || '?'}
    </div>
  );
}

const BADGE_COLORS: Record<string, string> = {
  emerald: 'bg-accent-soft text-accent',
  sand: 'bg-warning-soft text-warning',
  red: 'bg-danger-soft text-danger',
  amber: 'bg-warning-soft text-warning',
  ink: 'bg-surface-card2 text-surface-muted'
};

export function Badge({ children, color = 'emerald' }: { children: ReactNode; color?: keyof typeof BADGE_COLORS }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold tracking-wide ${BADGE_COLORS[color]}`}>
      {children}
    </span>
  );
}

export function ChevronRow({ children, onClick }: { children: ReactNode; onClick?: () => void }) {
  return (
    <div onClick={onClick} className="flex items-center gap-3">
      <div className="flex-1 min-w-0">{children}</div>
      <ChevronRight size={17} strokeWidth={2.3} className="text-surface-muted/70 flex-shrink-0" />
    </div>
  );
}
