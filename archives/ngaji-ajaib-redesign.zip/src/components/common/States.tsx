import { ClipboardList, AlertTriangle, RefreshCw } from 'lucide-react';

export function LoadingState({ label = 'Memuat data...' }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-surface-muted gap-3">
      <div className="w-7 h-7 border-[3px] border-surface-card2 border-t-accent rounded-full animate-spin" />
      <span className="text-ios-subhead">{label}</span>
    </div>
  );
}

export function EmptyState({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-14 px-6">
      <div className="w-14 h-14 rounded-full bg-surface-card2 shadow-neu-pressed flex items-center justify-center mb-3">
        <ClipboardList size={24} className="text-surface-muted" />
      </div>
      <h3 className="text-ios-nav text-surface-text mb-1">{title}</h3>
      {description && <p className="text-ios-footnote text-surface-muted max-w-xs">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-14 px-6">
      <div className="w-14 h-14 rounded-full bg-surface-card2 shadow-neu-pressed flex items-center justify-center mb-3">
        <AlertTriangle size={24} className="text-danger" />
      </div>
      <h3 className="text-ios-nav text-surface-text mb-1">Terjadi kesalahan</h3>
      <p className="text-ios-footnote text-surface-muted max-w-xs">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="ios-active mt-4 inline-flex items-center gap-1.5 text-ios-subhead font-medium text-accent">
          <RefreshCw size={14} /> Coba lagi
        </button>
      )}
    </div>
  );
}
