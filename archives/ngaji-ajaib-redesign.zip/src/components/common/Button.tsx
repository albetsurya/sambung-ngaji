import type { ButtonHTMLAttributes, ReactNode } from 'react';

interface Props extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  fullWidth?: boolean;
  children: ReactNode;
}

const VARIANTS: Record<string, string> = {
  primary: 'bg-accent text-white shadow-card hover:bg-accent-dark active:bg-accent-dark disabled:opacity-50 disabled:shadow-none',
  secondary: 'bg-surface-card text-accent border border-accent/40 hover:bg-accent-soft active:bg-accent-soft',
  ghost: 'bg-transparent text-surface-text hover:bg-surface-card2 active:bg-surface-card2',
  danger: 'bg-danger text-white shadow-card hover:opacity-95 active:opacity-90 disabled:opacity-50 disabled:shadow-none'
};

export function Button({ variant = 'primary', fullWidth, className = '', children, ...rest }: Props) {
  return (
    <button
      className={`min-h-[48px] px-5 rounded-xl font-semibold text-[15px] transition-all duration-200 ease-out active:scale-[0.98] disabled:active:scale-100 ${VARIANTS[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}
