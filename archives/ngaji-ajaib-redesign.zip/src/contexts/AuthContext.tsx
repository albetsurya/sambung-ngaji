// AuthContext.tsx
import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from "react";
import type { User } from "../types";
import { authApi } from "../services/authApi";
import { getToken, clearToken } from "../services/api";

interface AuthContextValue {
  user: User | null;
  loading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const token = getToken();
      console.log(
        "🔐 AuthProvider: checking token:",
        token ? "present" : "none",
      );

      if (!token) {
        setLoading(false);
        return;
      }

      try {
        const u = await authApi.validateSession();
        console.log("✅ AuthProvider: session valid, user:", u);
        setUser(u);
      } catch (error) {
        console.error("❌ AuthProvider: session invalid, clearing token");
        clearToken();
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function login(username: string, password: string) {
    console.log("🔐 AuthProvider.login called");
    const u = await authApi.login(username, password);
    setUser(u);
  }

  async function logout() {
    console.log("🔐 AuthProvider.logout called");
    await authApi.logout();
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth harus dipakai di dalam AuthProvider");
  return ctx;
}
